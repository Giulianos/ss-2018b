package ar.edu.itba.ss.Types;

public enum WallCollisionType {
    VERTICAL,
    HORIZONTAL
}
