package ar.edu.itba.ss.Forces;

public interface Force {
    public void evaluate();
    public Double getX();
    public Double getY();
}
